package com.example.chat_bot

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
